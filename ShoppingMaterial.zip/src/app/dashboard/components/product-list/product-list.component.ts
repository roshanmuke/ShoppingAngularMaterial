import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from "@angular/core";
import { adminProductRes } from "../../interface/product";
import { MatPaginator } from "@angular/material/paginator";
import { MatTableDataSource } from "@angular/material/table";
import {MatSort} from '@angular/material/sort';


import { ProductService } from '../../services/product.service';
@Component({
  selector: "app-product-list",
  templateUrl: "./product-list.component.html",
  styleUrls: ["./product-list.component.scss"],
})
export class ProductListComponent implements OnInit,OnChanges {
  @Input("productArr") productArr = [];
  showCaseArr:any = [];
  @Input("role") role = 1;
  @Output() deleteEvent = new EventEmitter();
  //dataSource:any=[];
  dataSource:any = new MatTableDataSource<adminProductRes>(this.productArr);

  displayedColumns=[];
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
   @ViewChild(MatSort, {static: true}) sort: MatSort;

 

  orderSize=true;


 
  constructor(private productService:ProductService) {}

  ngOnInit(): void {
  
    this.displayedColumns = ['Id', 'Images','Name', 'Color', 'Size','Price','Edit','View','Delete'];
    this.dataSource =this.productArr;

    //this.dataSource.sort = this.sort;
    
    this.dataSource.paginator = this.paginator;
    }


  ngOnChanges(): void{
    
   
  }

 
  
    deleteProduct(id,name) {
      let bool = window.confirm(`Are you sure you want to delete ${name}`);
      if (bool) {
        this.productService.deleteProduct(id).subscribe(
          (res) => {
            this.deleteEvent.emit();
          },
          (err) => {
            console.log(err);
          }
        );
      }
    }

   

    
}


