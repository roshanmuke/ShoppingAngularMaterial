export interface IProductRes {
    Data: null;
    ErrorCode: number;
    Message: string;
    Status: boolean;
  }

  export interface adminProductRes{

    Product_ID:number;
    Product_Name:string;
    Product_Size:number;
    Product_Color:String;
    Product_Price:number;
  }